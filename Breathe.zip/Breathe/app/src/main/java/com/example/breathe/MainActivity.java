package com.example.breathe;

import android.content.Intent;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.github.florent37.viewanimator.AnimationListener;
import com.github.florent37.viewanimator.ViewAnimator;

import java.text.MessageFormat;

public class MainActivity extends AppCompatActivity {

    private ImageView breatheImg;
    private TextView breathsTxt;
    private TextView timeTxt;
    private TextView sessionTxt;
    private Button startButton;
    private TextView guideTxt;
    private Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        breatheImg = (ImageView)findViewById(R.id.breatheImg);
        breathsTxt = (TextView)findViewById(R.id.breathtaken);
        timeTxt = (TextView)findViewById(R.id.lastBreathAt);
        sessionTxt = (TextView)findViewById(R.id.todayMinutes);
        startButton = (Button)findViewById(R.id.startButton);
        guideTxt = (TextView)findViewById(R.id.guideTxt);
        prefs = new Prefs(this);
        startIntroAnimation();

        sessionTxt.setText(MessageFormat.format("{0} min today", prefs.getSessions()));
        breathsTxt.setText(MessageFormat.format("{0} Breaths", prefs.getbreaths()));
        timeTxt.setText(prefs.getDate());
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startAnimation();
            }
        });
    }

    private void startIntroAnimation(){
        ViewAnimator
                .animate(guideTxt)
                .scale(0,1)
                .duration(1500)
                .onStart(new AnimationListener.Start() {
                    @Override
                    public void onStart() {
                        guideTxt.setText("Breathe");
                    }
                })
                .start();
    }

    private void startAnimation(){
        ViewAnimator
                .animate(breatheImg)
                .alpha(0,1)
                .onStart(new AnimationListener.Start() {
                    @Override
                    public void onStart() {
                        guideTxt.setText("Inhale...Exhale");
                    }
                })
                .decelerate()
                .duration(1000)
                .thenAnimate(breatheImg)
                .scale(0.02f,1.5f,0.02f)
                .rotation(360)
                .repeatCount(6)
                .accelerate()
                .duration(5000)
                .onStop(new AnimationListener.Stop() {
                    @Override
                    public void onStop() {
                        guideTxt.setText("Good Job");
                        breatheImg.setScaleX(1.0f);
                        breatheImg.setScaleY(1.0f);

                        prefs.setSessions(prefs.getSessions() + 1);
                        prefs.setbreaths(prefs.getbreaths() + 1);
                        prefs.setDate(System.currentTimeMillis());

                        new CountDownTimer(2000, 1000) {
                            @Override
                            public void onTick(long l) {

                            }

                            @Override
                            public void onFinish() {
                            startActivity(new Intent(getApplicationContext(),MainActivity.class));
                            finish();
                            }
                        }.start();

                    }
                })
                .start();

    }
}
